package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonSign {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\TOPUP\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver d = new ChromeDriver();
		d.get("http://amazon.in/");
		WebElement e = d.findElement(By.id("nav-link-yourAccount"));
		e.click();
		e = d.findElement(By.name("email"));
		e.sendKeys("sushanth678@gmail.com");
		e.submit();
		 
		e = d.findElement(By.id("ap_password"));
		e.sendKeys("sushanth1997");
		e.submit();
		e = d.findElement(By.id("signInSubmit"));
		e.click();
		
		WebElement e1 = d.findElement(By.className("nav-line-1"));
		
		e1 = d.findElement(By.id("nav-item-signout"));
		e1.click();
		System.out.println(d.getTitle());
	}
}
