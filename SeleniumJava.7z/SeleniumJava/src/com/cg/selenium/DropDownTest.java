package com.cg.selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By.ByTagName;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownTest {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\TOPUP\\Selenium\\chromedriver_win32\\chromedriver.exe");
        WebDriver d=new ChromeDriver();
        d.get("http://localhost:4200");
       WebElement e=d.findElement(By.tagName("select"));
       Select s=new Select(e);
       s.selectByValue("java");
       
       e = d.findElement(By.linkText("Click About"));
		e.click();
       
		JavascriptExecutor j=(JavascriptExecutor)d;
         j.executeScript("alert('hello JS Executor')");
         Alert a=d.switchTo().alert();
         a.accept();
	}

}
